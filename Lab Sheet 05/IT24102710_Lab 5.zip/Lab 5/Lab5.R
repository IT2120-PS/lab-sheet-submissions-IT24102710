setwd("C:\\Users\\Nidula Nuran\\Desktop\\Campus\\Lab\\2Y 1S\\PS\\Lab 5")

Delivery_Times=read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")

names(Delivery_Times)<-c("X")

histogram<-hist(X,main="Deliver Times",breaks=seq(20,70,length=10),right=FALSE)


cum.freq<-cumsum(histogram$counts)

breaks <- histogram$breaks

new <- c()

for(i in 1:length(breaks)){
  if(i == 1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

plot(breaks,new,type='l', main="Cumulative Frequency Polygon for Delivery times",xlab = "Delivery Times (minutes)",
     ylab = "Cumulative Frequency",ylim = c(0, max(cum.freq)))

